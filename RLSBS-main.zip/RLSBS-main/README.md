Deep Reinforcement Learning for Semisupervised Hyperspectral Band Selection
Jie Feng; Di Li; Jing Gu; Xianghai Cao; Ronghua Shang; Xiangrong Zhang; Licheng Jiao
https://ieeexplore.ieee.org/abstract/document/9358199
